package com.example.mypicks

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object Downloader {
    private val client = OkHttpClient()
    suspend fun save(context: Context, c: Candidate): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = client.newCall(Request.Builder().url(c.imageUrl).build()).execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}"); r.body!!.bytes()
            }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "mypicks_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MyPicks")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore")
            context.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            true
        }.getOrDefault(false)
    }
}
