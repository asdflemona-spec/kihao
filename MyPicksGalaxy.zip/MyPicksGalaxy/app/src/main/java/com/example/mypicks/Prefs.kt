package com.example.mypicks

import android.content.Context
import java.security.MessageDigest

class Prefs(context: Context) {
    private val p = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    var wifiOnly: Boolean get() = p.getBoolean("wifi", true); set(v) = p.edit().putBoolean("wifi", v).apply()
    var dailyLimit: Int get() = p.getInt("limit", 20); set(v) = p.edit().putInt("limit", v).apply()
    fun rate(url: String, liked: Boolean) = p.edit().putBoolean("rated_${hash(url)}", liked).apply()
    fun wasLiked(url: String) = p.getBoolean("rated_${hash(url)}", false)
    fun markSaved(url: String) = p.edit().putBoolean("saved_${hash(url)}", true).apply()
    fun isSaved(url: String) = p.getBoolean("saved_${hash(url)}", false)
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
