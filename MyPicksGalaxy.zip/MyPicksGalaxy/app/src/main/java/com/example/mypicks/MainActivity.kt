package com.example.mypicks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.work.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedule()
        setContent { MaterialTheme { App() } }
    }
    private fun schedule() {
        val prefs = Prefs(this)
        val constraints = Constraints.Builder().setRequiredNetworkType(if (prefs.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build()
        val req = PeriodicWorkRequestBuilder<AutoPickWorker>(24, TimeUnit.HOURS).setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

@Composable fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Candidate>>(emptyList()) }
    var idx by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("불러오는 중…") }
    var wifi by remember { mutableStateOf(prefs.wifiOnly) }

    fun load() { scope.launch { status="불러오는 중…"; items = runCatching { CommonsRepository.fetch() }.getOrDefault(emptyList()); idx=0; status=if(items.isEmpty()) "후보를 불러오지 못했습니다." else "${items.size}개 후보" } }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("MyPicks", style = MaterialTheme.typography.headlineMedium)
        Text("성인·비노골적 공개 사진용 개인 앱", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        val c = items.getOrNull(idx)
        if (c != null) {
            AsyncImage(model=c.imageUrl, contentDescription=c.title, modifier=Modifier.fillMaxWidth().weight(1f), contentScale=ContentScale.Fit)
            Text(c.title, maxLines=1)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                Button(onClick={ prefs.rate(c.imageUrl,false); idx=(idx+1).coerceAtMost(items.size) }) { Text("👎") }
                Button(onClick={ scope.launch { prefs.rate(c.imageUrl,true); if (Downloader.save(ctx,c)) { prefs.markSaved(c.imageUrl); status="Pictures/MyPicks에 저장됨" }; idx=(idx+1).coerceAtMost(items.size) } }) { Text("👍 저장") }
            }
        } else { Spacer(Modifier.weight(1f)); Button(onClick={load()}) { Text("새 후보 불러오기") }; Spacer(Modifier.weight(1f)) }
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("자동 작업은 Wi-Fi에서만")
            Switch(checked=wifi,onCheckedChange={ wifi=it; prefs.wifiOnly=it })
        }
        Text("$status · 하루 최대 ${prefs.dailyLimit}장", style=MaterialTheme.typography.bodySmall)
    }
}
