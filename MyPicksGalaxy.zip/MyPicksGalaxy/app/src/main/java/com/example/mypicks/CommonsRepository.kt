package com.example.mypicks

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

object CommonsRepository {
    private val client = OkHttpClient()
    private val blocked = listOf("nude", "nudity", "porn", "sex", "erotic", "fetish", "lingerie", "underage", "teen", "child", "girl", "boy")

    suspend fun fetch(limit: Int = 30): List<Candidate> = withContext(Dispatchers.IO) {
        // Deliberately constrained to adult, non-explicit portrait/fashion photography.
        val q = URLEncoder.encode("adult woman fashion portrait photograph", "UTF-8")
        val url = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=$limit&prop=imageinfo|info&iiprop=url&iiurlwidth=1200&inprop=url&format=json&origin=*"
        val req = Request.Builder().url(url).header("User-Agent", "MyPicksGalaxy/1.0 personal-use").build()
        val body = client.newCall(req).execute().use { it.body?.string().orEmpty() }
        val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return@withContext emptyList()
        val out = mutableListOf<Candidate>()
        pages.keys().forEach { key ->
            val p = pages.getJSONObject(key)
            val title = p.optString("title")
            val lower = title.lowercase()
            if (blocked.any { lower.contains(it) }) return@forEach
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@forEach
            val image = ii.optString("thumburl", ii.optString("url"))
            val page = p.optString("fullurl")
            if (image.startsWith("https://") && page.startsWith("https://")) out += Candidate(title, image, page)
        }
        out.shuffled()
    }
}
